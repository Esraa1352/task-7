# Changelog

## [v1.0.3](https://github.com/bjoernboeckle/L293D/tree/v1.0.3)
- Added "GetCurrentMotorSpeed" function to read current set speed
- Added "SetStopPWMValue" function to use a custom PWM value for a stopped motor


## [v1.0.2](https://github.com/bjoernboeckle/L293D/tree/v1.0.2)
- Added example for ESP32
- Fixes for ESP32


## [v1.0.1](https://github.com/bjoernboeckle/L293D/tree/v1.0.1)
- Fixed resolution for ESP32
- Improved examples

## [v1.0.0](https://github.com/bjoernboeckle/L293D/tree/v1.0.0)
- Initial release